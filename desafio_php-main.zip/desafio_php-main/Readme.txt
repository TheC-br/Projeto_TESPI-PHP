Aplicação web CRUD de clientes.

A aplicação foi desenvolvida em PHP, com o sistema Xampp (PHP, MariaDB-MySQL e Apache, no Windows).

Para iniciar:

1) Criar a pasta desafio_php no localhost do Apache;
2) Colocar os arquivos nesta pasta;
3) Criar dois bancos de dados no PhPAdmin:

Obs: suário e senha padão do PhPAdmin: root e ""

4) Após criado os bancos de dados, criar duas tabelas;

- Para criar as tabelas, basta acessar (pela URL) os arquivos pdo_tabela.php e usuarios_tabela.php; ambos criam as tabelas.

5) O sistema estará pronto para ser usado;

Pasta inicial: desafio_php
